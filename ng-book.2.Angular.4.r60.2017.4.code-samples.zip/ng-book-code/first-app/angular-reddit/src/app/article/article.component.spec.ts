/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { ArticleComponent } from './article.component';

describe('Component: Article', () => {
  it('should create an instance', () => {
    const component = new ArticleComponent();
    expect(component).toBeTruthy();
  });
});
